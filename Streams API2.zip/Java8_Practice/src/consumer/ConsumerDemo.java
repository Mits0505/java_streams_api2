package consumer;

import java.util.function.Consumer;

public class ConsumerDemo {
    public static void main(String[] args) {
        Consumer<String> c = s->System.out.println(s);

        System.out.println("Result of consumer");
        c.accept("Mitali");
        c.accept("Aggarwal");
    }

}
