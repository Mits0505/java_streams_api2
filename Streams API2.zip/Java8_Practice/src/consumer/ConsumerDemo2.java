package consumer;

import java.util.ArrayList;
import java.util.function.Consumer;

class Movie{
    String name;
    String actor;
    String actress;

    public Movie(String name, String actor, String actress) {
        this.name = name;
        this.actor = actor;
        this.actress = actress;
    }
}
public class ConsumerDemo2 {
    public static void main(String[] args) {
        ArrayList<Movie> movies = new ArrayList<>();
        populate(movies);

        Consumer<Movie> c = m-> {
            System.out.println("Movie Name:"+m.name);
            System.out.println("Movie Actor:"+m.actor);
            System.out.println("Movie Actress:"+m.actress);
            System.out.println();
        };

        for(Movie m: movies)
            c.accept(m);
    }

    private static void populate(ArrayList<Movie> movies) {
        movies.add(new Movie("Bahubali","Prabhas","Anushka"));
        movies.add(new Movie("Rayees","Sharukh","Sunny"));
        movies.add(new Movie("Dangal","Ameer","Ritu"));
        movies.add(new Movie("Sultan","Salman","Anushka"));
    }
}

