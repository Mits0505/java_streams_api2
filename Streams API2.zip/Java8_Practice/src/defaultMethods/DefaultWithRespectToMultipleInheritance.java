package defaultMethods;

interface Left{
    default void m1(){
        System.out.println("Left Interface m1() method.");
    }
}

interface Right{
    default void m1(){
        System.out.println("Right Interface m1() method.");
    }
}

public class DefaultWithRespectToMultipleInheritance implements Left,Right{
    @Override
    public void m1() {
       // System.out.println("Our own m1() method. ");
        Left.super.m1();
    }

    public static void main(String[] args) {
        DefaultWithRespectToMultipleInheritance obj = new DefaultWithRespectToMultipleInheritance();
        obj.m1();
    }
}
