package functions;

import java.util.ArrayList;
import java.util.function.Function;
import java.util.function.Predicate;

public class EmployeeSalaryIncrement {
    public static void main(String[] args) {
        ArrayList<Employee> employees = new ArrayList<>();
        populate(employees);
        System.out.println("Employee details before salary increment: ");
        System.out.println(employees);

        Predicate<Employee> p = e-> e.salary<3500;
        Function<Employee,Employee> f = e->{
            e.salary+=1000;
            return e;
        };

        ArrayList<Employee> employeesAfterSalaryUpdate = new ArrayList<>();
        for(Employee e: employees){
            if(p.test(e)){
                f.apply(e);
                employeesAfterSalaryUpdate.add(e);
            }
        }
        System.out.println("Employee details after salary increment: ");
        System.out.println(employeesAfterSalaryUpdate);
    }

    public static void populate(ArrayList<Employee> l) {
        l.add(new Employee("Sunny",1000));
        l.add(new Employee("Bunny",2000));
        l.add(new Employee("Chinny",3000));
        l.add(new Employee("Pinny",4000));
        l.add(new Employee("Vinny",5000));
    }
}
