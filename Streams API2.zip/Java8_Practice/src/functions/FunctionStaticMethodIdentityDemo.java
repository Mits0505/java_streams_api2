package functions;

import java.util.function.Function;

public class FunctionStaticMethodIdentityDemo {
    public static void main(String[] args) {
        Function f = Function.identity();

        System.out.println("Result of f() is: "+f.apply("Mitali"));
    }
}
