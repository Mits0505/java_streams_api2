package LambdaUsage;

import functionalInterface.FunctionInterface1;

class BeforeLambda1 implements FunctionInterface1 {

    @Override
    public void m1() {
        System.out.println("Normal implementation of lambda.");
    }

    public static void main(String[] args) {
        FunctionInterface1 i = new BeforeLambda1();
        i.m1();
    }
}
