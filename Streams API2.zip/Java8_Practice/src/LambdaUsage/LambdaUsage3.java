package LambdaUsage;

import functionalInterface.FunctionInterface3;

public class LambdaUsage3 {
    public static void main(String[] args) {
        FunctionInterface3 i = s->s.length();
        System.out.println("Length of Mitali is "+i.getLength("Mitali"));
        System.out.println("Length of Aggarwal is "+i.getLength("Aggarwal"));

    }
}
