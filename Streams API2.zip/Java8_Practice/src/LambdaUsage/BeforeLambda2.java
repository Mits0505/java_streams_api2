package LambdaUsage;

import functionalInterface.FunctionInterface2;

public class BeforeLambda2 implements FunctionInterface2 {

    @Override
    public void sum(int a, int b) {
        System.out.println("Sum of "+a+" and "+b+" is "+(a+b));
    }

    public static void main(String[] args) {
        FunctionInterface2 i = new BeforeLambda2();
        i.sum(10,20);
    }
}
