package anonymous;

interface Interf {
    public void m1();
}
class ThisInAnonymousClass {
    int x = 777;
    public void m2() {
        Interf i =new Interf () {
            int x = 888;
            @Override
            public void m1() {
                System.out.println(x); //888
                System.out.println(this.x); //888
            }
        };
         i.m1();
    }
    public static void main(String[] args) {
        ThisInAnonymousClass t = new ThisInAnonymousClass();
        t.m2();
    }
 }
