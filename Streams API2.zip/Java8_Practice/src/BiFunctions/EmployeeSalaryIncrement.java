package BiFunctions;

import java.util.ArrayList;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;

class Employee1{
    String name;
    double salary;

    public Employee1(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public String toString(){
        return String.format("{%s %.2f}",name,salary);
    }
}
public class EmployeeSalaryIncrement {
    public static void main(String[] args) {
        ArrayList<Employee1> emploees = new ArrayList<>();

        BiFunction<String,Double,Employee1> f = (n,s) -> new Employee1(n,s);

        emploees.add(f.apply("Mitali",10000.00));
        emploees.add(f.apply("Rajat",20000.00));
        emploees.add(f.apply("Lokesh",30000.00));

        System.out.println("Salary Before Increment");
        System.out.println(emploees);

        BiConsumer<Employee1,Double> c = (e,s)-> e.salary +=s;
        for(Employee1 e : emploees){
            c.accept(e,500.00);
        }

        System.out.println("Salary After Increment");
        System.out.println(emploees);
    }
}
