package predefinedFunctionalInterfaces;

import java.util.ArrayList;
import java.util.function.Predicate;

class Employee{
    String name;
    String designation;
    double salary;
    String city;

    public Employee(String name, String designation, double salary, String city) {
        this.name = name;
        this.designation = designation;
        this.salary = salary;
        this.city = city;
    }

    @Override
    public String toString() {
        return String.format("[%s,%s,%.2f,%s]",name,designation,salary,city);
    }

    public boolean equals(Object obj){
      Employee e = (Employee)obj;
      return name.equals(e.name) && designation.equals(e.designation) && salary == e.salary && city.equals(e.city);
    }
}
public class EmployeeApplication {

    public static void main(String[] args) {
        ArrayList<Employee> al = new ArrayList<>();
        populate(al);

        Predicate<Employee> managerPredicate = e->e.designation.equals("Manager");
        System.out.println("Manager Information");
        display(managerPredicate,al);

        Predicate<Employee> banglorePredicate = e->e.city.equals("Bangalore");
        System.out.println("Banglore Employee Information");
        display(banglorePredicate,al);

        Predicate<Employee> salaryPredicate = e->e.salary<20000;
        System.out.println("Employees having salary less than 20000");
        display(salaryPredicate,al);

        System.out.println("Banglore Managers Information");
        display(banglorePredicate.and(managerPredicate),al);

        System.out.println("All employees who are manager or having salary less than 20000");
        display(managerPredicate.or(salaryPredicate),al);

        System.out.println("All employees who are not managers");
        display(managerPredicate.negate(),al);

        Employee e1 = new Employee("Durga","CEO",30000,"Hyderabad");
        Employee e2 = new Employee("Sunny","Manager",20000,"Hyderabad");

        Predicate<Employee> isCEO = Predicate.isEqual(new Employee("Durga","CEO",30000,"Hyderabad"));
        System.out.println(e1+" is CEO: "+isCEO.test(e1));
        System.out.println(e2+" is CEO: "+isCEO.test(e2));
    }

    public static void display(Predicate<Employee> p, ArrayList<Employee> al){
        for(Employee e : al){
            if(p.test(e))
                System.out.println(e);
        }
        System.out.println("********************************************");
    }

    public static void populate(ArrayList<Employee> list) {
         list.add(new Employee("Durga","CEO",30000,"Hyderabad"));
         list.add(new Employee("Sunny","Manager",20000,"Hyderabad"));
         list.add(new Employee("Mallika","Manager",20000,"Bangalore"));
         list.add(new Employee("Kareena","Lead",15000,"Hyderabad"));
         list.add(new Employee("Katrina","Lead",15000,"Bangalore"));
         list.add(new Employee("Anushka","Developer",10000,"Hyderabad"));
         list.add(new Employee("Kanushka","Developer",10000,"Hyderabad"));
         list.add(new Employee("Sowmya","Developer",10000,"Bangalore"));
    }
}
