package predefinedFunctionalInterfaces;

import java.util.ArrayList;
import java.util.function.Predicate;

public class PredicateDemo3 {

    public static void main(String[] args) {
        String names[] = {"Durga","",null,"Ravi","","Shiva",null};

        Predicate<String> validName = s -> s!=null && s.length()!=0;

        ArrayList<String> validNamesList = new ArrayList<>();

        for (String name : names){
            if(validName.test(name))
                validNamesList.add(name);
        }

        System.out.println("The list of valid names is: ");
        System.out.println(validNamesList);
    }
}
